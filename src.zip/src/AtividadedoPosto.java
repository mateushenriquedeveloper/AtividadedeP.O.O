
public interface AtividadedoPosto {
double abastecer(MeioDeTransporte mt, double litros);
void calibrarPneu();
void trocaOleo(MeioDeTransporte mt, String oleo);

}

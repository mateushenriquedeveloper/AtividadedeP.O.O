public class Main {
	public static void main(String[] args) {
		Posto1 p = new Posto1();
		Automovel a = new Automovel();
		a.combustivel = "etanol";
		System.out.println(p.abastecer(a, 50));
		a.oleo = "sintetico";
		System.out.println(p.trocarOleo(a, 4));
		Caminhao c = new Caminhao();
		c.combustivel = "diesel";
		System.out.println(p.abastecer(c, 50));
		c.oleo = "semi";
		System.out.println(p.trocarOleo(c, 30));
		Moto m = new Moto();
		m.combustivel = "gasolina";
		System.out.println(p.abastecer(m, 25));
		m.oleo = "mineral";
		System.out.println(p.trocarOleo(m, 1));
	}
}

public class Caminhao extends MeioDeTransporte{

}

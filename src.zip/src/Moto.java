
public class Moto extends MeioDeTransporte {

}

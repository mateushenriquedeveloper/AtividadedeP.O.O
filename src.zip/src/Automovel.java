
public class Automovel extends MeioDeTransporte {



}

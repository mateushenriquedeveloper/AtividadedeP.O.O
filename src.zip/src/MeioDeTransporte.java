
public abstract class MeioDeTransporte {
 String combustivel;
 String oleo;

 
}

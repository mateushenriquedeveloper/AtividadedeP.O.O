public class Posto1 implements AtividadedoPosto{
	 final double gasolina = 5.99;
	 final double etanol = 4.99;		 
	 final double diesel = 3.99;
	 final double sintetico = 35.00;
	 final double semi = 30.00;
	 final double mineral = 20.00;
	 double total;
	 
	 public double abastecer(MeioDeTransporte mt, double litros) {
		 if(mt.combustivel.equals("gasolina")) {
		total = gasolina*litros;
		 }
		 else if(mt.combustivel.equals("etanol")) {
				total = etanol*litros; 
	 }
		 else  {
				total = diesel*litros; 
	 }
		return total; 

	 }

	public double trocarOleo(MeioDeTransporte mt, double litros) {
		if(mt.oleo.equals("mineral")) {
			total = mineral*litros; 
		}
		else if(mt.oleo.equals("semi")) {
			total = semi*litros;
		}
		else {
			total = sintetico*litros;
		}
		
	 return total;	
	}

	@Override
	public void calibrarPneu() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trocaOleo(MeioDeTransporte mt, String oleo) {
		// TODO Auto-generated method stub
		
	}

}